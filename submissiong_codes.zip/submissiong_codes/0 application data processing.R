rm(list = ls())
library("tidyverse")
library("ggplot2")
library("MetricsWeighted")
library("boot")
library("ggpubr")

####################################
######### read data
####################################
setwd("~/")

cog <- read.csv("cog.DSST.2020.csv")
statins <- read.csv("statins.csv")
bloodall <- read.csv("bloodall.csv")
bloodall_visit1 <- bloodall[which(bloodall$visitcode == "Visit 1 In-Person"), ]
data_change <- read.csv("data.change.csv")
medhx <- read.csv("medhx.data.annotated.with.biomarkers.08.2021.csv")

####################################
######## data pre-processing
####################################

#exclude subs with missing baseline 
cog <- cog %>% drop_na(id, DSST.b)


invalid_base <- which(cog$DSST.b == -10 | cog$ovalidr.b < 4)    #remove invalid baseline information
cog <- cog[-invalid_base, ]                    

#set invalid scores
cog$DSST.2.invalid <- 0 
cog$DSST.2.invalid[which(cog$DSST.2 == -10)] <- 1
cog$DSST.2[cog$DSST.2 == -10] <- NA

write.csv(cog, file = "subcog.csv")

###merge with other datasets
cog <- merge(x = cog, y = bloodall_visit1[, c("subject", "fhsch", "fhshdl", "fhsldl")], by = "subject", all.x = TRUE)
#cog <- merge(x = cog, y = data_change[, c("subject", "sysb.b")], by = "subject", all.x = TRUE)
cog <- merge(x = cog, y = medhx[, c("subject", "diabetes.inc", "smoke.now")], by = "subject", all.x = TRUE)

cog$sex <- as.numeric(as.factor(cog$sex)) - 1  #female = 0, male = 1
cog$fhsch <- as.numeric(cog$fhsch)
cog$fhshdl <- as.numeric(cog$fhshdl)
cog$fhsldl <- as.numeric(cog$fhsldl)
cog$educ <- as.numeric(cog$educ)

#exclude subs with missing baseline 
cog <- cog %>% drop_na(fhsch, fhshdl, fhsldl, educ) 

#compute framingham risk scores
rf <- (log(cog$Age.enrollment) * 3.06117) + (log(cog$fhsch) * 1.12370) - (log(cog$fhshdl) * 0.93263) + cog$smoke.now + cog$diabetes.inc - 23.9802
cog$fh_risk = 100 * (1 - 0.88936^(exp(rf)))
cog <- cog[complete.cases(cog$fh_risk), ]


#### In all population
cogid <- unique(cog$subject)
cat("all subject count:", length(cogid), "\n")

## who take second test
cat("#subs has value at 2nd test:", sum(!is.na(cog$DSST.2)), "\n") 

## who has no value at their second test
cat("#subs has NA at 2nd test:", sum(is.na(cog$DSST.2)), "\n") 

## died before the second test
cog <- cog %>%
  mutate(die_before_test = case_when(
    is.na(DSST.2) & is.na(Age.II) & (Alive == "No" | is.na(Alive)) ~ 1,   #
    TRUE ~ 0
  ))

par(mfrow = c(1, 1))
hist(cog$DOB, main = "Date of Birth")
p<-ggplot(cog, aes(x=DOB)) + 
  geom_histogram(color="black", fill="white") + 
  labs(title=" ",x="Year of Birth", y = "Count") +
  theme_classic()


write.csv(cog, "cog_data_NoMissingBase.csv", row.names = F)
