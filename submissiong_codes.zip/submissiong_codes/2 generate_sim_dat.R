rm(list = ls())
library(ggplot2)
library("tidyverse")
library("ks")
library("reldist")
library("boot")
library("MetricsWeighted")
set.seed(15)
pathdir <- "~/"
setwd(pathdir)


#################################
####### Point treatment
#################################

##function to generate data
genobt <- function(total.n, prob.l, prob.Al0, prob.Al1,
                   prob.d.l0A0, prob.d.l0A1, prob.d.l1A0, prob.d.l1A1,
                   beta0, beta1, beta2,
                   pats.sd, d.value) {
  l <- rbinom(total.n, 1, prob.l)   #generate L
  l0.num <- sum(l == 0)
  l1.num <- sum(l == 1)
  
  Aforl0 <- rbinom(l0.num, 1, prob.Al0) #generate A on the L = 0 stratum
  l0.A1.num <- sum(Aforl0)
  l0.A0.num <- l0.num - l0.A1.num
  
  Aforl1 <- rbinom(l1.num, 1, prob.Al1) #generate A on the L = 1 stratum
  l1.A1.num <- sum(Aforl1)
  l1.A0.num <- l1.num - l1.A1.num
  
  A <- numeric(total.n)
  A[which(l == 0)] <- Aforl0
  A[which(l == 1)] <- Aforl1
  
  D.l0.A0 <- rbinom(l0.A0.num, 1, prob.d.l0A0) #generate death
  D.l1.A0 <- rbinom(l1.A0.num, 1, prob.d.l1A0)
  
  D.l0.A1 <- rbinom(l0.A1.num, 1, prob.d.l0A1)
  D.l1.A1 <- rbinom(l1.A1.num, 1, prob.d.l1A1)
  
  pats <- data.frame(l, A)
  
  D <- numeric(total.n)
  D[which(pats$l == 0 & pats$A == 0)] <- D.l0.A0
  D[which(pats$l == 0 & pats$A == 1)] <- D.l0.A1
  D[which(pats$l == 1 & pats$A == 0)] <- D.l1.A0
  D[which(pats$l == 1 & pats$A == 1)] <- D.l1.A1
  
  pats <- data.frame(l, A, D)                        #combine all covariates together
  meanY <- beta0 + beta1 * pats$A + beta2 * pats$l   #generate outcomes
  Y <- sapply(meanY, function(x) rnorm(1, x, pats.sd))
  
  pats <- data.frame(l, A, D, Y)                     #combine
  pats[which(pats$D == 1), "Y"] <- d.value           #assign death values
  
  return(pats = pats)
}



##### generate files
## coefficients
n.sims = 2000
prob.l = 0.6     #P(L=1) 
prob.Al0 = 0.3   #P(A=1|L=0)
prob.Al1 = 0.7   #P(A=1|L=1)
betas = c(0, -0.9, 3)  #beta0, beta1, and beta2
pats.sd = 1           #standard deviation
d.value = -1000

#prob.d.l0A0 = 0.25   #P(D=1|L=0, A=0)
#prob.d.l0A1 = 0.08   #P(D=1|L=0, A=1)
#prob.d.l1A0 = 0.35   #P(D=1|L=1, A=0)
#prob.d.l1A1 = 0.15   #P(D=1|L=1, A=1)

prob.d.l0A0 = 0.10  #P(D=1|L=0, A=0)
prob.d.l0A1 = 0.05   #P(D=1|L=0, A=1)
prob.d.l1A0 = 0.16   #P(D=1|L=1, A=0)
prob.d.l1A1 = 0.08   #P(D=1|L=1, A=1)


pats500 <- list()
for (i in 1:n.sims) {
  pats <- genobt(
    total.n = 500, prob.l, prob.Al0, prob.Al1,
    prob.d.l0A0, prob.d.l0A1, prob.d.l1A0, prob.d.l1A1,
    beta0 = betas[1], beta1 = betas[2], beta2 = betas[3],
    pats.sd, d.value
  )
  pats500[[i]] <- pats
}
save(pats500, file = "pats500.2024.rda")


pats1500 <- list()
for (i in 1:n.sims) {
  pats <- genobt(
    total.n = 1500, prob.l, prob.Al0, prob.Al1,
    prob.d.l0A0, prob.d.l0A1, prob.d.l1A0, prob.d.l1A1,
    beta0 = betas[1], beta1 = betas[2], beta2 = betas[3],
    pats.sd, d.value
  )
  pats1500[[i]] <- pats
}
save(pats1500, file = "pats1500.2024.rda")


pats5000 <- list()
for (i in 1:n.sims) {
  pats <- genobt(
    total.n = 5000, prob.l, prob.Al0, prob.Al1,
    prob.d.l0A0, prob.d.l0A1, prob.d.l1A0, prob.d.l1A1,
    beta0 = betas[1], beta1 = betas[2], beta2 = betas[3],
    pats.sd, d.value
  )
  pats5000[[i]] <- pats
}
save(pats5000, file = "pats5000.2024.rda")




#################################
####### TV treatment
#################################
##function
genobt <- function(total.n, prob.l0,
                   d1.beta, A0.beta, l1.beta, A1.beta, d2.beta, y.beta,
                   pats.sd, d.value) {
  l0 <- rbinom(total.n, 1, prob.l0)
  

  p.A0 <- A0.beta[1] * (l0 == 0) + A0.beta[2] * (l0 == 1)
  A0 <- rbinom(total.n, 1, p.A0)
  pats <- data.frame(l0, A0)
  
  p.d1 <- inv.logit(d1.beta[1] + d1.beta[2] * pats$l0 + d1.beta[3] * pats$A0)
  D1 <- rbinom(total.n, 1, p.d1)
  pats <- data.frame(l0, A0, D1)
  
  p.l1 <- inv.logit(l1.beta[1] + l1.beta[2] * pats$l0 + l1.beta[3] * pats$A0)
  l1 <- rbinom(total.n, 1, p.l1)
  pats <- data.frame(l0, A0, D1, l1)
  
  p.A1 <- inv.logit(A1.beta[1] + A1.beta[2] * pats$l0 + A1.beta[3] * pats$A0 + A1.beta[4] * pats$l1)
  A1 <- rbinom(total.n, 1, p.A1)
  pats <- data.frame(l0, A0, D1, l1, A1)
  
  p.d2 <- inv.logit(d2.beta[1] + d2.beta[2] * pats$l0 + d2.beta[3] * pats$A0 + d2.beta[4] * pats$l1 + d2.beta[5] * pats$A1)
  D2 <- rbinom(total.n, 1, p.d2)
  
  pats <- data.frame(l0, A0, D1, l1, A1, D2)
  pats[which(pats$D1 == 1), c("l1", "A1", "D2")] <- NA
  
  meanY <- y.beta[1] + y.beta[2] * pats$l0 + y.beta[3] * pats$A0 + y.beta[4] * pats$l1 + y.beta[5] * pats$A1
  Y <- sapply(meanY, function(x) rnorm(1, x, pats.sd))
  pats <- data.frame(pats, Y)
  pats[which(pats$D1 == 1 | pats$D2 == 1), "Y"] <- d.value
  
  return(pats = pats)
}



####generate files
##coefficients
prob.l0 <- 0.6
d.value <- -1000
pats.sd <- 1


#coefficients to generate each covariates, see manuscript Section simulation study for details
# A0.beta <- c(0.3, 0.7)    
# l1.beta <- c(-1, 2, -1)
# d1.beta <- c(-1.8, 0.5, -0.8)
# A1.beta <- c(-2.5, 0.8, 3, 1)
# d2.beta <- c(-1.8, 0.3, -0.4, 0.5, -0.6)
# y.beta<- c(0, 2, -0.4, 2.2, -0.4)


A0.beta <- c(0.3, 0.7)    
l1.beta <- c(-1, 2, -1)
d1.beta <- c(-2.5, 0.5, -0.6)
A1.beta <- c(-2.5, 0.8, 3, 1)
d2.beta <- c(-3.0, 0.3, -0.4, 0.5, -0.4)
y.beta<- c(0, 2, -0.4, 2.2, -0.4)



pats500.tv <- list()
for (i in 1:2000) {
  pats <- genobt(
    total.n = 500, prob.l0 = 0.6,
    d1.beta = d1.beta, A0.beta = A0.beta, l1.beta = l1.beta, A1.beta = A1.beta, d2.beta = d2.beta, y.beta = y.beta,
    pats.sd = 1, d.value = -1000
  )
  pats500.tv[[i]] <- pats
}
save(pats500.tv, file = "pats500.tv.2024.rda")

pats1500.tv <- list()
for (i in 1:2000) {
  pats <- genobt(
    total.n = 1500, prob.l0 = 0.6,
    d1.beta = d1.beta, A0.beta = A0.beta, l1.beta = l1.beta, A1.beta = A1.beta, d2.beta = d2.beta, y.beta = y.beta,
    pats.sd = 1, d.value = -1000
  )
  pats1500.tv[[i]] <- pats
}
save(pats1500.tv, file = "pats1500.tv.2024.rda")

pats5000.tv <- list()
for (i in 1:2000) {
  pats <- genobt(
    total.n = 5000, prob.l0 = 0.6,
    d1.beta = d1.beta, A0.beta = A0.beta, l1.beta = l1.beta, A1.beta = A1.beta, d2.beta = d2.beta, y.beta = y.beta,
    pats.sd = 1, d.value = -1000
  )
  pats5000.tv[[i]] <- pats
}
save(pats5000.tv, file = "pats5000.tv.2024.rda")







