rm(list = ls())
library("tidyverse")
library("ggplot2")
library("MetricsWeighted")
library("boot")
library("ggpubr")

#!!!!please set the age group in line 24-25 to get the desired age group results

####################################
######### read data
####################################
pathdir <- "~/"
setwd(pathdir)

cog <- read.csv("cog_data_NoMissingBase.csv")
statins <- read.csv("statins.csv")
bloodall <- read.csv("bloodall.csv")
bloodall_visit1 <- bloodall[which(bloodall$visitcode == "Visit 1 In-Person"), ]
data_change <- read.csv("data.change.csv")
medhx <- read.csv("medhx.data.annotated.with.biomarkers.08.2021.csv")


#set the age group
age_low_range = 55
age_high_range = 70

cog_sample <- cog %>%
  filter(Age.I >= age_low_range  & Age.I < age_high_range )
cogid <- unique(cog_sample$subject)



####################################
#### Cog Sample Preprocessing
####################################
################## statins usage in subjects  (we are using this!)
statinsid <- unique(statins$subject)
statins_sample <- statins[which(statins$subject %in% cog_sample$subject), ]

mins <- aggregate(statins_sample[, "contactyr"], list(statins_sample$subject), min) #the 1st contact year
statins_offon_ids <- mins$Group.1[which(mins$x > 0)]  #index for those who started statins after baseline



#first part: participants on statins at baseline
oneBaseStatin_ids <- statins_sample %>% filter(contactyr == 0) %>% distinct(subject) %>% pull(subject)
cog_sample_onBaseStatin <- cog_sample[which(cog_sample$subject %in% oneBaseStatin_ids), ]

#dead before the 2nd DSST
dead_before_DSST_id_onStatin <- cog_sample_onBaseStatin %>% filter(die_before_test == 1) %>% pull(subject)
#missing second DSST
sum(is.na(cog_sample_onBaseStatin$DSST.2)) - length(dead_before_DSST_id_onStatin)
#invalid second DSST
sum(cog_sample_onBaseStatin$DSST.2.invalid)

#missing ids, will be used later
allmissing_ids_onStatin <- cog_sample_onBaseStatin %>% filter(is.na(DSST.2)) %>% pull(subject)
allmissing_ids_onStatin <- allmissing_ids_onStatin[-which(allmissing_ids_onStatin %in% dead_before_DSST_id_onStatin)]   #subtract those missing due to death
allmissing_ids_onStatin <- allmissing_ids_onStatin[-which(allmissing_ids_onStatin %in% cog_sample_onBaseStatin$subject[cog_sample_onBaseStatin$DSST.2.invalid==1])] #subtract the invalid test

#Crude survival-incorporated median
cog_sample_onBaseStatin$DSST.2[which(cog_sample_onBaseStatin$subject %in% dead_before_DSST_id_onStatin)] <- -1000
cog_sample_onBaseStatin$DSST_diff <- cog_sample_onBaseStatin$DSST.2 - cog_sample_onBaseStatin$DSST.b
median(cog_sample_onBaseStatin$DSST_diff, na.rm = TRUE)

#######
#second part: participants off statins at baseline
offBaseStatin_id <- cog_sample$subject[which(!cog_sample$subject %in% oneBaseStatin_ids)] #subs index that are not in statins index
cog_sample_offBaseStatin <- cog[which(cog$subject %in% offBaseStatin_id), ]

#dead before 2nd DSST
dead_before_DSST_id_offStatin <- cog_sample_offBaseStatin %>% filter(die_before_test == 1) %>% pull(subject)
##number of missings 
sum(is.na(cog_sample_offBaseStatin$DSST.2)) - length(dead_before_DSST_id_offStatin)
#number invalids
sum(cog_sample_offBaseStatin$DSST.2.invalid)

#missings
allmissing_ids_offStatin <- cog_sample_offBaseStatin %>% filter(is.na(DSST.2)) %>% pull(subject)
allmissing_ids_offStatin <- allmissing_ids_offStatin[-which(allmissing_ids_offStatin %in% dead_before_DSST_id_offStatin)]   #subtract those missing due to death
allmissing_ids_offStatin <- allmissing_ids_offStatin[-which(allmissing_ids_offStatin %in% cog_sample_offBaseStatin$subject[cog_sample_offBaseStatin$DSST.2.invalid==1])]

#crude median
cog_sample_offBaseStatin[which(cog_sample_offBaseStatin$subject %in% dead_before_DSST_id_offStatin), "DSST.2"] <- -1000
cog_sample_offBaseStatin$DSST_diff <- cog_sample_offBaseStatin$DSST.2 - cog_sample_offBaseStatin$DSST.b
median(cog_sample_offBaseStatin$DSST_diff, na.rm = TRUE)

#####################
####cog_sample initiating
cog_sample$base_statins <- 0
cog_sample$base_statins[which(cog_sample$subject %in% oneBaseStatin_ids)] <- 1
cog_sample$censored <- 0

cog_sample$visit1_statin_status <- 0
cog_sample$visit2_statin_status <- 0

cog_sample[(cog_sample$base_statins == 1), "visit1_statin_status"] <- 1
cog_sample[(cog_sample$base_statins == 1), "visit2_statin_status"] <- 1

cog_sample$onoffstatins <- 0   ###include those are off statins due to death
cog_sample$onstatins_before_death <- 0
cog_sample$offonstatins <- 0
cog_sample$offstatins_before_death <- 0

cog_sample$censored[which(cog_sample$subject %in% allmissing_ids_onStatin)] <- 1
cog_sample$censored[which(cog_sample$subject %in% allmissing_ids_offStatin)] <- 1

par(mfrow = c(2, 1))
hist(cog_sample[cog_sample$base_statins == 0, 'fhsch'], main = "cholesterols levels at baseline in a = 0", xlab = "cholesterol level")
hist(cog_sample[cog_sample$base_statins == 1, 'fhsch'], main = "cholesterols levels at baseline in a = 1", xlab = "cholesterol level")

p0<-ggplot(cog_sample[cog_sample$base_statins == 0, ], aes(x=fhsch)) + 
  geom_histogram(color="black", fill="white", binwidth = 15) + 
  labs(title=" ",x=" ", y = "Count") +
  xlim(0, 400) + ylim(0, 70) +
  ggtitle(expression(paste("A"[0], "= 0"))) +
  theme(
    panel.background = element_rect(fill='transparent'),
    plot.title = element_text(size=18, face= "bold")
  )

p1<-ggplot(cog_sample[cog_sample$base_statins == 1, ], aes(x=fhsch)) + 
  geom_histogram(color="black", fill="white", binwidth = 15) + 
  labs(title=" ",x="Cholesterol", y = "Count") +
  xlim(0, 400) + ylim(0, 70) +
  ggtitle(expression(paste("A"[0], "= 1"))) +
  theme(
    panel.background = element_rect(fill='transparent'),
    plot.title = element_text(size=18, face= "bold"),
    axis.title.x = element_text(size=16, face="bold", colour = "black"),    
  )

tiff(paste(pathdir, "cholesterol_unweighted.tiff"), units="in", width=5, height=5.5, res=300)
ggarrange(p0 , p1,
          ncol = 1, nrow = 2)
dev.off()



######################################################
#### Annotating people deviating from their regimen (time-dependent)
######################################################
#########on->off statins: people who was on statins first and then become off statins
statinsonoff <- statins[which(statins$subject %in% oneBaseStatin_ids), ]

#max contact year
maxs <- aggregate(statinsonoff[, "contactyr"], list(statinsonoff$subject), max)
colnames(maxs) <- c("subject", "contactyr")

#if max contact year less than 3, that means before the 1st visit, it becomes off statins
visit_1_statins_off_ids <- maxs %>% filter(contactyr < 3) %>% pull(subject)
#if max contact year less than 6, that means before the 2nd visit, it becomes off statins
visit_2_statins_off_ids <- maxs %>% filter(contactyr < 6) %>% pull(subject)

cog_sample <- cog_sample %>%
  mutate(
    visit1_statin_status = case_when(
      subject %in% visit_1_statins_off_ids ~ 0,   #mark them as off statins at visit 1
      TRUE ~ visit1_statin_status
    ),
    visit2_statin_status = case_when( 
      subject %in% visit_2_statins_off_ids ~ 0,   #mark them as off statins at visit 2
      TRUE ~ visit2_statin_status
    ),
    onoffstatins = case_when(
      subject %in% visit_1_statins_off_ids  ~ 1,
      subject %in% visit_2_statins_off_ids  ~ 1,
      TRUE ~ onoffstatins
    ),
  )

##########off/on statins: people who was off statins first and then become on statins
statinsoffon <- statins[which(statins$subject %in% statins_offon_ids), ]

#minimum contact year
mins <- aggregate(statinsoffon[, "contactyr"], list(statinsoffon$subject), min)
colnames(mins) <- c("subject", "contactyr")

# if min contact year less than 3, that means before the 1st visit, it started statins
visit_1_statins_on_ids <- mins %>% filter(contactyr < 3) %>% pull(subject)

# if min contact year less than 6, that means before the 2nd visit, it started statins
visit_2_statins_on_ids <- mins %>% filter(contactyr < 6) %>% pull(subject)

cog_sample <- cog_sample %>%
  mutate(
    visit1_statin_status = case_when(
      subject %in% visit_1_statins_on_ids ~ 1,  #mark them as on statins at visit 1
      TRUE ~ visit1_statin_status
    ),
    visit2_statin_status = case_when(
      subject %in% visit_2_statins_on_ids ~ 1,  #mark them as on statins at visit 2
      TRUE ~ visit2_statin_status
    ),
    offonstatins = case_when(
      subject %in% visit_1_statins_on_ids ~ 1,
      subject %in% visit_2_statins_on_ids ~ 1,
      TRUE ~ offonstatins
    )
  )


####################################
#### Annotating death (time dependent)
####################################
cog_sample$visit1_death <- 0
cog_sample$visit2_death <- 0

death_ids <- c(dead_before_DSST_id_onStatin, dead_before_DSST_id_offStatin)

cog_sample$death <- 0
cog_sample$death[which(cog_sample$subject %in% death_ids)] <- 1

death_date_information <- cog_sample[which(cog_sample$subject %in% death_ids), c("subject", "Age.enrollment", "Age.last.contact")]
death_date_information$death_interval <- death_date_information$Age.last.contact - death_date_information$Age.enrollment

cog_sample[cog_sample$subject %in% death_date_information$subject[death_date_information$death_interval <= 3], 'visit1_death'] <- 1
cog_sample[cog_sample$subject %in% death_date_information$subject[death_date_information$death_interval <= 6], 'visit2_death'] <- 1

###on statins before death
cog_sample[cog_sample$base_statins == 1 & cog_sample$visit1_statin_status == 0 & cog_sample$visit1_death == 1, 'onstatins_before_death'] <- 1  #becuase they are already dead, so the visitor cannot get their information at visit 1
cog_sample[cog_sample$base_statins == 1 & cog_sample$visit1_statin_status == 1 & cog_sample$visit2_statin_status == 0 & cog_sample$visit2_death == 1, 'onstatins_before_death'] <- 1

###off statins before death
cog_sample[cog_sample$base_statins == 0 & cog_sample$visit1_statin_status == 1 & cog_sample$visit1_death == 1, 'offstatins_before_death'] <- 1
cog_sample[cog_sample$base_statins == 0 & cog_sample$visit1_statin_status  == 0 & cog_sample$visit2_statin_status == 1 & cog_sample$visit2_death == 1, 'offstatins_before_death'] <- 1

cog_sample[which(cog_sample$subject %in% death_ids), "DSST.2"] <- -100
cog_sample$diff <- cog_sample$DSST.2 - cog_sample$DSST.b
cog_sample$diff[which(cog_sample$subject %in% death_ids)] <- -100


###############################################################################
#########################Modelling: IPTW + IPCW################################
###############################################################################

####################################
########## IPTW
trt_fit <- glm(base_statins ~ Age.enrollment + sex, family = binomial(), data = cog_sample)

summary(trt_fit)
cog_sample$ps_t <- ifelse(cog_sample$base_statins == 1, predict(trt_fit, type = "response"), 1 - predict(trt_fit, type = "response"))

cog_sample$w_a <- 1/cog_sample$ps_t

##plot for weighted fhsch
cog_sample$fhsch_weight <- cog_sample$fhsch * cog_sample$w_a

p0<-ggplot(cog_sample[cog_sample$base_statins == 0, ], aes(x=fhsch, weight = w_a)) + 
  geom_histogram(color="black", fill="white", binwidth = 15) + 
  labs(title=" ",x="Cholesterol", y = "Count") +
  xlim(0, 400) +
  ggtitle(expression(paste("A"[0], "= 0"))) +
  theme_classic()

p1<-ggplot(cog_sample[cog_sample$base_statins == 1, ], aes(x=fhsch, weight = w_a)) + 
  geom_histogram(color="black", fill="white", binwidth = 15) + 
  labs(title=" ",x="Cholesterol", y = "Count") +
  xlim(0, 400) +
  ggtitle(expression(paste("A"[0], "= 1"))) +
  theme_classic()


tiff(paste(pathdir, "cholesterol_weighted.tiff"), units="in", width=5, height=5.5, res=300)
ggarrange(p0 , p1,
          ncol = 1, nrow = 2)
dev.off()


####################################
#### Time dependent IPCW and temp results
####################################

#################part 1: participants on/off statins
#first visit
visit1_fit <- glm((1-visit1_statin_status) ~ Age.enrollment + sex + educ + fhsch + fhshdl + fhsldl + fh_risk + smoke.now, family = binomial(), data = cog_sample[cog_sample$base_statins == 1 & cog_sample$visit1_death == 0, ])
cog_sample$p1 <- 1
cog_sample[cog_sample$base_statins == 1 & cog_sample$visit1_death == 0, 'p1'] <- 1 - predict(visit1_fit, type = "response")

#second visit
visit2_fit <- glm((1-visit2_statin_status) ~ Age.enrollment + sex + educ+ fhsch + fhshdl + fhsldl + fh_risk + smoke.now, family = binomial(), data = cog_sample[cog_sample$base_statins == 1 & cog_sample$visit1_death == 0 & cog_sample$visit1_statin_status == 1 & cog_sample$visit2_death == 0,])
cog_sample$p2 <- 1
cog_sample[cog_sample$base_statins == 1 & cog_sample$visit1_death == 0 & cog_sample$visit1_statin_status == 1 & cog_sample$visit2_death == 0, 'p2'] <- 1 - predict(visit2_fit, type = "response")

cog_sample$w_time_censor <- 1/(cog_sample$p1) * 1/(cog_sample$p2)
sum(cog_sample$w_time_censor)

#time-independent missingness
censoring_fit <- glm(censored ~  base_statins + Age.enrollment + sex + educ + fhsch + fhshdl + fh_risk + smoke.now, family = binomial(), data = cog_sample[cog_sample$base_statins == 1 & cog_sample$death == 0 & cog_sample$onoffstatins == 0,])
cog_sample$censoring_p <- 1
cog_sample[cog_sample$base_statins == 1 & cog_sample$death == 0 & cog_sample$onoffstatins == 0, 'censoring_p'] <- 1 - predict(censoring_fit, type = "response")
cog_sample$w_inde_censor <- 1/cog_sample$censoring_p

sum(cog_sample$w_inde_censor)

#invalid weight
invalid_denomin_fraction <- 1 - sum(cog_sample[cog_sample$base_statins == 1 & cog_sample$death == 0 & cog_sample$offonstatins ==0 & cog_sample$censored == 0, 'DSST.2.invalid'])/ 
  nrow(cog_sample[cog_sample$base_statins == 1 & cog_sample$death == 0 & cog_sample$offonstatins ==0 & cog_sample$censored == 0, ])

cog_sample <- cog_sample %>% 
  mutate(ps_c_invalid = ifelse(cog_sample$DSST.2.invalid == 1, 1/invalid_denomin_fraction, 1))


###sum up the results
cog_base_statins_dat <- cog_sample[cog_sample$base_statins == 1, ]
cog_base_statins_dat$w_tot <- 1
cog_base_statins_dat$w_tot <- cog_base_statins_dat$w_a *  cog_base_statins_dat$w_inde_censor  * cog_base_statins_dat$w_time_censor 

cog_base_statins_dat[cog_base_statins_dat$onoffstatins == 1 & cog_base_statins_dat$onstatins_before_death == 0, 'w_tot'] <- 0   #####those people should have weight 0
cog_base_statins_dat[cog_base_statins_dat$censored == 1, 'w_tot'] <- 0

sum(cog_base_statins_dat$w_tot)

##estimated probability of death
sum(cog_base_statins_dat[cog_base_statins_dat$death == 1, 'w_tot']) / sum(cog_base_statins_dat$w_tot)

#sur-med
weighted_quantile(cog_base_statins_dat$diff, w = cog_base_statins_dat$w_tot, probs = 0.5, na.rm = TRUE)

#################part 1: participants on/off statins
visit1_fit <- glm(visit1_statin_status ~ Age.enrollment + sex + educ + fhsch + fhshdl + fhsldl + fh_risk + smoke.now, family = binomial(), data = cog_sample[cog_sample$base_statins == 0 & cog_sample$visit1_death == 0, ])
cog_sample$p1 <- 1
cog_sample[cog_sample$base_statins == 0 & cog_sample$visit1_death == 0,'p1'] <- 1 - predict(visit1_fit, type = "response")

#second visit
visit2_fit <- glm(visit2_statin_status ~  Age.enrollment + sex + educ + fhsch + fhshdl + fhsldl + fh_risk + smoke.now, family = binomial(), data = cog_sample[cog_sample$base_statins == 0 & cog_sample$visit1_death == 0 & cog_sample$visit1_statin_status == 0 & cog_sample$visit2_death == 0,])
cog_sample$p2 <- 1
cog_sample[cog_sample$base_statins == 0 & cog_sample$visit1_death == 0 & cog_sample$visit1_statin_status == 0 & cog_sample$visit2_death == 0, 'p2'] <- 1 - predict(visit2_fit, type = "response")
cog_sample$w_time_censor <- 1/(cog_sample$p1) * 1/(cog_sample$p2)

#time-independent IPCW
censoring_fit <- glm(censored ~  base_statins + Age.enrollment + sex + educ + fhsch + fhshdl + fh_risk + smoke.now, family = binomial(), data = cog_sample[cog_sample$base_statins == 0 & cog_sample$death == 0 & cog_sample$offonstatins == 0,])
cog_sample$censoring_p <- 1
cog_sample[cog_sample$base_statins == 0 & cog_sample$death == 0 & cog_sample$offonstatins == 0, 'censoring_p'] <- 1 - predict(censoring_fit, type = "response")
cog_sample$w_inde_censor <- 1/cog_sample$censoring_p

#invalid weight
invalid_denomin_fraction <- 1 - sum(cog_sample[cog_sample$base_statins == 0 & cog_sample$death == 0 & cog_sample$offonstatins ==0 & cog_sample$censored == 0, 'DSST.2.invalid'])/ 
  nrow(cog_sample[cog_sample$base_statins == 0 & cog_sample$death == 0 & cog_sample$offonstatins ==0 & cog_sample$censored == 0, ])

cog_sample <- cog_sample %>% 
  mutate(ps_c_invalid = ifelse(cog_sample$DSST.2.invalid == 1, 1/invalid_denomin_fraction, 1))


###sum up the results
cog_base_nostatins_dat <- cog_sample[cog_sample$base_statins == 0, ]
cog_base_nostatins_dat$w_tot <- 1
cog_base_nostatins_dat$w_tot <- cog_base_nostatins_dat$w_a *  cog_base_nostatins_dat$w_inde_censor  * cog_base_nostatins_dat$w_time_censor 

cog_base_nostatins_dat[cog_base_nostatins_dat$offonstatins == 1 & cog_base_nostatins_dat$offstatins_before_death == 0, 'w_tot'] <- 0
cog_base_nostatins_dat[cog_base_nostatins_dat$censored == 1, 'w_tot'] <- 0

sum(cog_base_nostatins_dat[cog_base_nostatins_dat$death == 1, 'w_tot']) / sum(cog_base_nostatins_dat$w_tot)
weighted_quantile(cog_base_nostatins_dat$diff, w = cog_base_nostatins_dat$w_tot, probs = 0.5, na.rm = TRUE)


####################################
#### results and CI estimation
####################################

###go back to cog_sample
cog_sample[cog_sample$subject %in% cog_base_statins_dat$subject, 'w_tot'] <- cog_base_statins_dat$w_tot
cog_sample[cog_sample$subject %in% cog_base_nostatins_dat$subject, 'w_tot'] <- cog_base_nostatins_dat$w_tot

statins_idx <- cog_sample$base_statins == 1

death_a_0 <- sum(cog_sample[!statins_idx, ]$death * cog_sample[!statins_idx, ]$w_tot) / sum(cog_sample[!statins_idx, ]$w_tot)   
sur_med_a_0 <- weighted_quantile(cog_sample[!statins_idx, ]$diff, w = cog_sample[!statins_idx, ]$w_tot, probs = 0.5, na.rm = TRUE)
med_sur_a_0 <- weighted_quantile(cog_sample[!statins_idx & cog_sample$death == 0, ]$diff, w = cog_sample[!statins_idx & cog_sample$death == 0, ]$w_tot, probs = 0.5, na.rm = TRUE)


death_a_1 <- sum(cog_sample[statins_idx, ]$death * cog_sample[statins_idx, ]$w_tot) / sum(cog_sample[statins_idx, ]$w_tot)
sur_med_a_1 <- weighted_quantile(cog_sample[statins_idx, ]$diff, w = cog_sample[statins_idx, ]$w_tot, probs = 0.5, na.rm = TRUE)
med_sur_a_1 <- weighted_quantile(cog_sample[statins_idx & cog_sample$death == 0, ]$diff, w = cog_sample[statins_idx & cog_sample$death == 0, ]$w_tot, probs = 0.5, na.rm = TRUE)



get_CI <- function(dataset, random){ 
  d = dataset[random, ]
  statins_idx <- d$base_statins == 1
  death_a_0 <- sum(d[!statins_idx, ]$death * d[!statins_idx, ]$w_tot) / sum(d[!statins_idx, ]$w_tot)
  sur_med_a_0 <- weighted_quantile(d[!statins_idx, ]$diff, w = d[!statins_idx, ]$w_tot, probs = 0.5, na.rm = TRUE)
  
  med_sur_a_0 <- weighted_quantile(cog_sample[!statins_idx & cog_sample$death == 0, ]$diff, w = cog_sample[!statins_idx & cog_sample$death == 0, ]$w_tot, probs = 0.5, na.rm = TRUE)
  
  death_a_1 <- sum(d[statins_idx, ]$death * d[statins_idx, ]$w_tot) / sum(d[statins_idx, ]$w_tot)
  sur_med_a_1 <- weighted_quantile(d[statins_idx, ]$diff, w = d[statins_idx, ]$w_tot, probs = 0.5, na.rm = TRUE)
  
  med_sur_a_1 <- weighted_quantile(cog_sample[statins_idx & cog_sample$death == 0, ]$diff, w = cog_sample[statins_idx & cog_sample$death == 0, ]$w_tot, probs = 0.5, na.rm = TRUE)
  
  return(c(death_a_0, #estimated prob of death under a = 0
           death_a_1, #estimated prob of death under a = 1
           death_a_1 - death_a_0, #estimated difference of prob of death of a = 1 - a = 0
           sur_med_a_0, #survival-incorporated median under a = 0
           sur_med_a_1, #survival-incorporated median under a = 1
           sur_med_a_1- sur_med_a_0, #differences of survival-incorporated median between a = 1 - a = 0
           med_sur_a_0, #median in the survivors under a = 0
           med_sur_a_1, #median in the survivors under a = 1
           med_sur_a_1 - med_sur_a_0  #difference of median in the survivors between a = 1 - a = 0
  ))
}


bootres = boot(data = cog_sample,
               statistic = get_CI,
               R = 1000)
bootres


#iterate idex from 
get_boot_res <- function(i) {
  temp_res <- boot.ci(bootres, type = "perc", index = i)
  ci <- temp_res$percent[4:5]  # Extract percentile confidence interval
  c(temp_res$t0, Lower_CI = ci[1], Upper_CI = ci[2])  # Return results as a vector
}


# Use lapply to apply the function to indices 1 through 9
all_results <- lapply(1:9, get_boot_res)

# Combine the results into a dataframe
all_results_df <- do.call(rbind, all_results )
all_results_df


write.csv(all_results_df, paste0(age_low_range,"_", age_high_range,  "_all_results.csv"))

#############################
#######Demographics
##########################
input_data <- cog_sample

#demographics table 
sum_table_no_w <- function(input_data){
  
  #total number
  total_number <- nrow(input_data)
  
  #age at enrollment
  age_quan <- paste0("(", toString(quantile(input_data$Age.enrollment, probs = c(0.25,0.75))), ")")
  age <- paste(median(input_data$Age.enrollment), age_quan )
  
  #Female 0; Male 1
  female_per <- paste0("(",   round(1 - sum(input_data$sex) / nrow(input_data), 3), ")")
  sex <- paste(nrow(input_data) - sum(input_data$sex), female_per)
  
  #edu
  edu_quan <- paste0("(", toString( quantile(input_data$educ, probs = c(0.25,0.75))), ")")
  edu <- paste(median(input_data$educ), edu_quan)
  
  #smoking
  smoking_per <- paste0("(", round(sum(input_data$smoke.now)/nrow(input_data), 3), ")")
  smoking <- paste(sum(input_data$smoke.now), smoking_per)
  
  #cholesterol
  choles_quan <- paste0("(", toString(quantile(input_data$fhsch, probs = c(0.25,0.75))), ")") 
  choles <- paste(median(input_data$fhsch), choles_quan)
  
  #HDL cholesterol
  HDL_quan <- paste0("(", toString(quantile(input_data$fhshdl, probs = c(0.25,0.75))), ")") 
  HDL <- paste(median(input_data$fhshdl), HDL_quan)
  
  #LDL cholesterol
  LDL_quan <- paste0("(", toString(quantile(input_data$fhsldl, probs = c(0.25,0.75))), ")") 
  LDL <- paste(median(input_data$fhsldl), LDL_quan)
  
  #death
  death_per <- paste0("(", round(sum(input_data$death)/nrow(input_data), 3), ")")
  death <- paste(sum(input_data$death),  death_per)
  
  #all summary
  res_vec <- c(total_number, age, sex, edu, smoking, choles, HDL, LDL, death)
  
  return(res_vec)
}


all_res_sum <- sum_table_no_w(cog_sample)
offstatins_res_sum <- sum_table_no_w(cog_sample[cog_sample$base_statins == 0, ])
onstatins_res_sum <- sum_table_no_w(cog_sample[cog_sample$base_statins == 1, ])
all_res_sum <- cbind(all_res_sum, offstatins_res_sum, onstatins_res_sum)

rownames(all_res_sum) <- c(
  "total N",
  "age enroll",
  "sex",
  "educ",
  "smoking",
  "Cholesterol",
  "HDL",
  "LDL",
  "death"
)

write.csv(all_res_sum, paste0(age_low_range,"_", age_high_range,  "_characteristic table.csv") )



##crude death summary table
n_base_on_statins <- nrow(cog_sample) - sum(cog_sample$base_statins) #baseline not using statins
n_base_off_statins <- sum(cog_sample$base_statins)   #baseline use statins

prob_base_on_statins <- sum(cog_sample[cog_sample$base_statins == 0, "death"]) / sum(cog_sample$base_statins == 0) 
prob_base_off_statins <- sum(cog_sample[cog_sample$base_statins == 1, "death"]) / sum(cog_sample$base_statins == 1) 

death_tab <- rbind(c(n_base_on_statins, prob_base_on_statins), c(n_base_off_statins, prob_base_off_statins))
print(death_tab)


######weighted demographics table
input_data = cog_sample

sum_table_weighted <- function(input_data){
  
  #total number
  total_number <- sum(input_data$w_a)
  
  #age at enrollment
  age_quan <- paste0("(", toString(weighted_quantile(input_data$Age.enrollment, w = input_data$w_a, probs = c(0.25,0.75))), ")")
  age <- paste(weighted_quantile(input_data$Age.enrollment, w = input_data$w_a, probs = 0.5), age_quan )
  
  #Female 0; Male 1
  female_per <- paste0("(",   round(1 - sum(input_data$sex * input_data$w_a) / total_number, 3), ")")
  sex <- paste(round(total_number - sum(input_data$sex * input_data$w_a), 1), female_per)
  
  #edu
  edu_quan <- paste0("(", toString( weighted_quantile(input_data$educ, w = input_data$w_a, probs = c(0.25,0.75))), ")")
  edu <- paste(weighted_quantile(input_data$educ, w = input_data$w_a, probs = 0.5), edu_quan)
  
  #smoking
  smoking_per <- paste0("(", round(sum(input_data$smoke.now * input_data$w_a)/total_number, 3), ")")
  smoking <- paste(round(sum(input_data$smoke.now * input_data$w_a), 1), smoking_per)
  
  #cholesterol
  choles_quan <- paste0("(", toString(weighted_quantile(input_data$fhsch, w = input_data$w_a, probs = c(0.25,0.75))), ")") 
  choles <- paste(weighted_quantile(input_data$fhsch, w = input_data$w_a, probs = 0.5), choles_quan)
  
  #HDL cholesterol
  HDL_quan <- paste0("(", toString(weighted_quantile(input_data$fhshdl, w = input_data$w_a, probs = c(0.25,0.75))), ")") 
  HDL <- paste(weighted_quantile(input_data$fhshdl, w = input_data$w_a, probs = 0.5), HDL_quan)
  
  #LDL cholesterol
  LDL_quan <- paste0("(", toString(weighted_quantile(input_data$fhsldl, w = input_data$w_a, probs = c(0.25,0.75))), ")") 
  LDL <- paste(weighted_quantile(input_data$fhsldl, w = input_data$w_a, probs = 0.5), LDL_quan)
  
  #death
  death_per <- paste0("(", round(sum(input_data$death * input_data$w_a)/total_number, 3), ")")
  death <- paste(round(sum(input_data$death * input_data$w_a), 1) ,  death_per)
  
  #all summary
  res_vec <- c(round(total_number, 1), age, sex, edu, smoking, choles, HDL, LDL, death)
  
  return(res_vec)
}


all_res_sum <- sum_table_weighted(cog_sample)
offstatins_res_sum <- sum_table_weighted(cog_sample[cog_sample$base_statins == 0, ])
onstatins_res_sum <- sum_table_weighted(cog_sample[cog_sample$base_statins == 1, ])
all_res_sum <- cbind(all_res_sum, offstatins_res_sum, onstatins_res_sum)

rownames(all_res_sum) <- c(
  "total N",
  "age enroll",
  "sex",
  "educ",
  "smoking",
  "Cholesterol",
  "HDL",
  "LDL",
  "death"
)

write.csv(all_res_sum, paste0(age_low_range,"_", age_high_range,  "_w_characteristic table.csv") )
