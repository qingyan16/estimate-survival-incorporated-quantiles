rm(list = ls() )
library("MetricsWeighted")
library("boot")
library("quantreg")
set.seed(30)
pathdir <- "~/"
setwd(pathdir)

#this file takes a long time to run, the description under each setting

#####################
#######load the files
#####################
## point treatment setting dataset
load(file = "pats1500.2024.rda")
load(file = "pats5000.2024.rda")

## time varying setting dataset
load(file = "pats1500.tv.2024.rda")
load(file = "pats5000.tv.2024.rda")

###############################################################################
###################bootstrap: point-trt #######################################
###############################################################################
# This takes about 16 hours to run

#estimate the quantiles
get.q <- function(test.A, pats.data, tau = 0.5, type = "normalized") {
  if (type == "normalized") {
    w <- (pats.data$A == test.A) / (pats.data$ps * nrow(pats.data))
    q <- weighted_quantile(pats.data$Y, w = w, probs = tau)
  } else { #stablized weight
    w <- (pats.data$A == test.A) / pats.data$ws
    sw <- w / sum(w)
    q <- weighted_quantile(pats.data$Y, w = sw, probs = tau)
  }
  return(q)
}

##bootstrap statistics
sims_PS <- function( data, indices, ps.est = T, test.A = 1  ){
  temp_d = data[indices, ]
  
  if(ps.est == T){
    psmod <- glm(A ~ l, family = "binomial", data = temp_d)
    temp.ps <- predict(psmod, type = "response")
    temp_d$ps <- ifelse(temp_d$A == 1, temp.ps, 1 - temp.ps)
  }else{
    temp_d$trueps <- ifelse(temp_d$l == 1, 0.7, 0.3)
    temp_d$trueps <- ifelse(temp_d$A == 1, temp_d$trueps, 1 - temp_d$trueps)
    temp_d$ps <- temp_d$trueps
  }
  
  d.sim = get.q(test.A = 1, temp_d, tau = 0.5)
  return(d.sim)
}

##function to get all CIs
getallCI <- function(n.patients, ps.est, n.sims){
  allCI <- c()
  for ( i in 1:n.sims){
    if( i %% 50 == 0)
      print(i)
  
    pats <- switch(
      toString(n.patients),
    #read from loaded data
      "1500" = pats1500[[i]],
      "5000" = pats5000[[i]]
    )
  
    tempboot <- boot( data = pats, statistic = sims_PS, ps.est = ps.est, R = 2000)
    tempci <- boot.ci( tempboot, type = "perc")
    allCI <- rbind( allCI, tempci$percent[4:5] )
  }
    return(allCI)
}

#function to calculate coverage proability
coverage_sum <- function(resCI, truth){
  count = 0
  for ( i in 1:n.sims ){
    if ( resCI[i, 1] <= truth & resCI[i, 2] >= truth){
      count = count + 1
    }
  }
  return(count)
}


n.sims = 1000
##
resCI <- getallCI("1500", ps.est = T, n.sims)
point_est_ps_CI_1500 <- coverage_sum(resCI, 0.606)

##
resCI <- getallCI("1500", ps.est = F, n.sims)
point_true_ps_CI_1500 <- coverage_sum(resCI, 0.606)

##
resCI <- getallCI("5000", ps.est = T, n.sims)
point_est_ps_CI_5000 <- coverage_sum(resCI, 0.606)

##
resCI <- getallCI("5000", ps.est = F, n.sims)
point_true_ps_CI_5000 <- coverage_sum(resCI, 0.606)



point_all_res <- rbind(c(point_est_ps_CI_1500 , point_true_ps_CI_1500), c(point_est_ps_CI_5000, point_true_ps_CI_5000))
point_all_res

write.csv(point_all_res, file = "point_coverage.csv")



###############################################################################
###################bootstrap: time-varying trt #######################################
###############################################################################
#this takes about 35 hours to run

inv.logit <- function(a) {
  return(exp(a) / (1 + exp(a)))
}

get.q.tv <- function(test.A, pats.data, tau = 0.5, type = c("SIM", "survivors")) {
  if (type == "survivors") {
    trt.inds <- (pats.data$A0 == test.A[1] & pats.data$A1 == test.A[2])
    trt.inds[is.na(trt.inds)] <- FALSE
    w <- trt.inds / (pats.data$ps * nrow(pats.data))
    q <- weighted_quantile(pats.data$Y, w = w, probs = tau)
  }
  if (type == "SIM") {
    trt.inds <- numeric(nrow(pats.data))
    w.id <- c(which(pats.data$A0 == test.A[1] & pats.data$A1 == test.A[2]), which(pats.data$A0 == test.A[1] & pats.data$D1 == 1))
    trt.inds[w.id] <- 1
    w <- trt.inds / (pats.data$ps)
    q <- weighted_quantile(pats.data$Y, w = w, probs = tau)
  }
  return(q)
}

##
addw <- function(pats.data, ps.est) {
  if (ps.est== T) {
    psmod.0 <- glm(A0 ~ l0, family = "binomial", data = pats.data)
    ps <- predict(psmod.0, type = "response")
    pats.data$ps <- ifelse(pats.data$A0 == 1, ps, 1 - ps)
    
    psmod.1 <- glm(A1 ~ l0 + A0 + l1, family = "binomial", data = pats.data)
    ps.1 <- predict(psmod.1, type = "response")
    
    a1.id <- which(pats.data$D1 == 0)
    pats.data[a1.id, "ps"] <- ifelse(pats.data[a1.id, "A1"] == 1, pats.data[a1.id, "ps"] * ps.1, pats.data[a1.id, "ps"] * (1 - ps.1))
  }
  if (ps.est == F) {
    pats.data$ps <- ifelse(pats.data$l0 == 1, 0.7, 0.3)
    pats.data$ps <- ifelse(pats.data$A0 == 1, pats.data$ps, 1 - pats.data$ps)
    
    
    A1.beta <- c(-2.5, 0.8, 3, 1)
    ps.1 <- inv.logit(A1.beta[1] + A1.beta[2] * (pats.data$l0 == 1) + A1.beta[3] * (pats.data$A0 == 1) + A1.beta[4] * (pats.data$l1 == 1))
    
    a1.id <- which(pats.data$D1 == 0)
    pats.data[a1.id, "ps"] <- ifelse(pats.data[a1.id, "A1"] == 1, pats.data[a1.id, "ps"] * ps.1[a1.id], pats.data[a1.id, "ps"] * (1 - ps.1[a1.id]))
  }
  
  return(pats.data)
}

##bootstrap statistics
sims_PS_TV <- function(data, indices, ps.est = T, test.A = c(1, 1)  ){
  temp_d = data[indices, ]
  
  temp_d <- addw(temp_d, ps.est = ps.est)
  d.sim = get.q.tv(test.A = c(1, 1), temp_d, tau = 0.5, type = "SIM")
  
  return(d.sim)
}


##function to get all CIs
getallCI.tv <- function(n.patients, ps.est, n.sims){
  allCI <- c()
  for ( i in 1:n.sims){
    if( i %% 50 == 0)
      print(i)
    
    pats <- switch(
      toString(n.patients),
      "1500" = pats1500.tv[[i]],
      "5000" = pats5000.tv[[i]]
    )
    
    tempboot <- boot(data = pats, statistic = sims_PS_TV, ps.est = T, R = 2000)
    tempci <- boot.ci( tempboot, type = "perc")
    allCI <- rbind( allCI, tempci$percent[4:5] )
  }
  return(allCI)
}


n.sims = 2000
##
resCI <- getallCI.tv("1500", ps.est = T, n.sims)
tv_est_ps_CI_tv_1500 <- coverage_sum(resCI, 0.395)

##
resCI <- getallCI.tv("1500", ps.est = F, n.sims)
tv_true_ps_CI_tv_1500 <- coverage_sum(resCI, 0.395)

##
resCI <- getallCI.tv("5000", ps.est = T, n.sims)
tv_est_ps_CI_tv_5000 <- coverage_sum(resCI, 0.395)

##
resCI <- getallCI.tv("5000", ps.est = F, n.sims)
tv_true_ps_CI_tv_5000 <- coverage_sum(resCI, 0.395)



tv_all_res <- rbind(c(tv_est_ps_CI_tv_1500 , tv_true_ps_CI_tv_1500), c(tv_est_ps_CI_tv_5000, tv_true_ps_CI_tv_5000))
tv_all_res

write.csv(tv_all_res, file = "tv_coverage.csv")


