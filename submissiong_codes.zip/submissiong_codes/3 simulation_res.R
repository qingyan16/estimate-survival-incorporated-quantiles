rm(list = ls())
library(ggplot2)
library("tidyverse")
library("ks")
library("reldist")
library("boot")
library("MetricsWeighted")
set.seed(15)
pathdir <- "~/"
setwd(pathdir)

#####################
#######load the files
#####################
## point treatment setting dataset
load(file = "pats500.2024.rda")
load(file = "pats1500.2024.rda")
load(file = "pats5000.2024.rda")


## time varying setting dataset
load(file = "pats500.tv.2024.rda")
load(file = "pats1500.tv.2024.rda")
load(file = "pats5000.tv.2024.rda")
################################################################
################### Simulation for Point-treatment setting
################################################################


#estimate the quantiles
get.q <- function(test.A, pats.data, tau = 0.5, type = "normalized") {
  if (type == "normalized") {
    w <- (pats.data$A == test.A) / (pats.data$ps * nrow(pats.data))
    q <- weighted_quantile(pats.data$Y, w = w, probs = tau)
  } else { #stablized weight
    w <- (pats.data$A == test.A) / pats.data$ws
    sw <- w / sum(w)
    q <- weighted_quantile(pats.data$Y, w = sw, probs = tau)
  }
  return(q)
}

getallres <- function(n.patients, ps.est) {
  for (i in 1:n.sims) {
    if (i %% 100 == 0) {
      print(i)
    }
    
    pats <- switch(
      toString(n.patients),
      #read from loaded data
      "500" = pats500[[i]],
      "1500" = pats1500[[i]],
      "5000" = pats5000[[i]]
    )
    
    ##estimate the propensity scores
    psmod <- glm(A ~ l, family = "binomial", data = pats)
    temp.ps <- predict(psmod, type = "response")
    pats$ps <- ifelse(pats$A == 1, temp.ps, 1 - temp.ps)
    
    if (ps.est == FALSE) {   ##if the setting is true propensity scores
      pats$trueps <- ifelse(pats$l == 1, 0.7, 0.3)
      pats$trueps <- ifelse(pats$A == 1, pats$trueps, 1 - pats$trueps)
      pats$ps <- pats$trueps
    }
    
    survivors <- pats[which(pats$D == 0), ]
    
    #median in the survivors
    w.a0alive[i] <- get.q(test.A = 0, survivors, tau = 0.5)    
    w.a1alive[i] <- get.q(test.A = 1, survivors, tau = 0.5)
    
    #unweighted survival-incorporated median
    pats.a0surmed[i] <- median(pats[which(pats$A == 0), ]$Y)
    pats.a1surmed[i] <- median(pats[which(pats$A == 1), ]$Y)
    
    #IPTW survival-incorporated median
    w.a0surmed[i] <- get.q(test.A = 0, pats, tau = 0.5)
    w.a1surmed[i] <- get.q(test.A = 1, pats, tau = 0.5)
  }
  res_df <- data.frame(w.a0alive,
                       w.a1alive,
                       pats.a0surmed,
                       pats.a1surmed,
                       w.a0surmed,
                       w.a1surmed)
  return(res_df)
}


#estimate rMSE in the results
sMSE <- function(obt, rct.m) {
  deathcol <- which(colSums((obt <= -100)) > 0)
  if (length(deathcol) == 0) {
    deathcol <- NaN
    cat("no one dies")
  }
  print(deathcol)
  
  rct.m[5] <- rct.m[3]
  rct.m[6] <- rct.m[4]
  
  res <- numeric(6)
  
  for (i in 1:6) {
    if (i %in% deathcol) {
      res[i] <- sqrt(mean((obt[rowSums(obt <= -100) <= 0, i] - rct.m[i])^2))
    } else {
      res[i] <- sqrt(mean((obt[, i] - rct.m[i])^2))
    }
  }
  
  names(res) <- c("w.a0alive", "w.a1alive", "o.a0surmed", "o.a1surmed", "w.a0surmed", "w.a1surmed")
  return(res)
}


#estimate bias in the results
sbias <- function(obt, rct.m) {
  deathcol <- which(colSums((obt <= -100)) > 0)
  if (length(deathcol) == 0) {
    deathcol <- NaN
    cat("no one dies")
  }
  print(deathcol)
  
  rct.m[5] <- rct.m[3]
  rct.m[6] <- rct.m[4]
  
  res <- numeric(6)
  
  for (i in 1:6) {
    if (i %in% deathcol) {
      res[i] <- mean(obt[rowSums(obt <= -100) <= 0, i]) - rct.m[i]
    } else {
      res[i] <- mean(obt[, i]) - rct.m[i]
    }
  }
  
  names(res) <- c("w.a0alive", "w.a1alive", "o.a0surmed", "o.a1surmed", "w.a0surmed", "w.a1surmed")
  return(res)
}


#####################parameters######################
n.sims <- 2000
w.a0alive <- numeric(n.sims)
w.a1alive <- numeric(n.sims)
pats.a0surmed <- numeric(n.sims)
pats.a1surmed <- numeric(n.sims)
w.a0surmed <- numeric(n.sims)
w.a1surmed <- numeric(n.sims)


##################Results of estimated PS#####################
ps.est <- T
res.obt500est <- getallres(500, ps.est)
res.obt1500est <- getallres(1500, ps.est)
res.obt5000est <- getallres(5000, ps.est)

## truth derived from maths, see appendix for detailed derivation
#a0 med in survivors
#a1 med in survivors
#a0 survival-incorporated median
#a1 survival-incorporated median
truth <- c(2.0018330, 1.1450627, 1.4493786, 0.9152996)

#rMSE results
round(sMSE(res.obt500est, truth), 3)
round(sMSE(res.obt1500est, truth), 3)
round(sMSE(res.obt5000est, truth), 3)


#bias results
round(sbias(res.obt500est, truth), 3)
round(sbias(res.obt1500est, truth), 3)
round(sbias(res.obt5000est, truth), 3)


w.a0surmed.sum <- cbind( c(sMSE(res.obt500est, truth)[5], sMSE(res.obt1500est, truth)[5], sMSE(res.obt5000est, truth)[5]),
                         c(sbias(res.obt500est, truth)[5], sbias(res.obt1500est, truth)[5], sbias(res.obt5000est, truth)[5]))

w.a1surmed.sum <- cbind( c(sMSE(res.obt500est, truth)[6], sMSE(res.obt1500est, truth)[6], sMSE(res.obt5000est, truth)[6]),
                         c(sbias(res.obt500est, truth)[6], sbias(res.obt1500est, truth)[6], sbias(res.obt5000est, truth)[6]))

o.a0surmed.sum <- cbind( c(sMSE(res.obt500est, truth)[3], sMSE(res.obt1500est, truth)[3], sMSE(res.obt5000est, truth)[3]),
                         c(sbias(res.obt500est, truth)[3], sbias(res.obt1500est, truth)[3], sbias(res.obt5000est, truth)[3]))

o.a1surmed.sum <- cbind(c(sMSE(res.obt500est, truth)[4], sMSE(res.obt1500est, truth)[4], sMSE(res.obt5000est, truth)[4]),
                          c(sbias(res.obt500est, truth)[4], sbias(res.obt1500est, truth)[4], sbias(res.obt5000est, truth)[4]))

summary_tab <- cbind(rbind(w.a0surmed.sum, w.a1surmed.sum), rbind(o.a0surmed.sum, o.a1surmed.sum))

rownames(summary_tab) <- c("a0_500", "a0_1500", "a0_5000", "a1_500", "a1_1500", "a1_5000")
colnames(summary_tab) <- c( "w.rmse",   #RMSE for IPTW
                            "w.bias",   #bias for IPTW
                            "o.rmse",   #RMSE for ordinary estimation
                            "o.bias")   #bias for ordinary estimatrion

summary_tab

write.csv(summary_tab, file = "PT.est.ps.res.csv")

##################Results of known PS######################
ps.est <- F
res.obt500true <- getallres(500, ps.est)
res.obt1500true <- getallres(1500, ps.est)
res.obt5000true <- getallres(5000, ps.est)

#rMSE results
round(sMSE(res.obt500true, truth), 3)
round(sMSE(res.obt1500true, truth), 3)
round(sMSE(res.obt5000true, truth), 3)

#bias results
round(sbias(res.obt500true, truth), 3)
round(sbias(res.obt1500true, truth), 3)
round(sbias(res.obt5000true, truth), 3)


w.a0surmed.sum <- cbind( c(sMSE(res.obt500true, truth)[5], sMSE(res.obt1500true, truth)[5], sMSE(res.obt5000true, truth)[5]),
                         c(sbias(res.obt500true, truth)[5], sbias(res.obt1500true, truth)[5], sbias(res.obt5000true, truth)[5]))

w.a1surmed.sum <- cbind( c(sMSE(res.obt500true, truth)[6], sMSE(res.obt1500true, truth)[6], sMSE(res.obt5000true, truth)[6]),
                         c(sbias(res.obt500true, truth)[6], sbias(res.obt1500true, truth)[6], sbias(res.obt5000true, truth)[6]))

o.a0surmed.sum <- cbind( c(sMSE(res.obt500true, truth)[3], sMSE(res.obt1500true, truth)[3], sMSE(res.obt5000true, truth)[3]),
                         c(sbias(res.obt500true, truth)[3], sbias(res.obt1500true, truth)[3], sbias(res.obt5000true, truth)[3]))

o.a1surmed.sum <- cbind(c(sMSE(res.obt500true, truth)[4], sMSE(res.obt1500true, truth)[4], sMSE(res.obt5000true, truth)[4]),
                        c(sbias(res.obt500true, truth)[4], sbias(res.obt1500true, truth)[4], sbias(res.obt5000true, truth)[4]))

summary_tab <- cbind(rbind(w.a0surmed.sum, w.a1surmed.sum), rbind(o.a0surmed.sum, o.a1surmed.sum))

rownames(summary_tab) <- c("a0_500", "a0_1500", "a0_5000", "a1_500", "a1_1500", "a1_5000")
colnames(summary_tab) <- c( "w.rmse", "w.bias", "o.rmse", "o.bias")

summary_tab

write.csv(summary_tab, file = "PT.know.ps.res.csv")


################################################################
################### Simulation for time varying treatment setting
################################################################
inv.logit <- function(a) {
  return(exp(a) / (1 + exp(a)))
}

get.q.tv <- function(test.A, pats.data, tau = 0.5, type = c("SIM", "survivors")) {
  if (type == "survivors") {
    trt.inds <- (pats.data$A0 == test.A[1] & pats.data$A1 == test.A[2])
    trt.inds[is.na(trt.inds)] <- FALSE
    w <- trt.inds / (pats.data$ps * nrow(pats.data))
    q <- weighted_quantile(pats.data$Y, w = w, probs = tau)
  }
  if (type == "SIM") {
    trt.inds <- numeric(nrow(pats.data))
    w.id <- c(which(pats.data$A0 == test.A[1] & pats.data$A1 == test.A[2]), which(pats.data$A0 == test.A[1] & pats.data$D1 == 1))
    trt.inds[w.id] <- 1
    w <- trt.inds / (pats.data$ps)
    q <- weighted_quantile(pats.data$Y, w = w, probs = tau)
  }
  return(q)
}

addw <- function(pats.data, ps.est) {
    if (ps.est== T) {
      psmod.0 <- glm(A0 ~ l0, family = "binomial", data = pats.data)
      ps <- predict(psmod.0, type = "response")
      pats.data$ps <- ifelse(pats.data$A0 == 1, ps, 1 - ps)
      
      psmod.1 <- glm(A1 ~ l0 + A0 + l1, family = "binomial", data = pats.data)
      ps.1 <- predict(psmod.1, type = "response")
      
      a1.id <- which(pats.data$D1 == 0)
      pats.data[a1.id, "ps"] <- ifelse(pats.data[a1.id, "A1"] == 1, pats.data[a1.id, "ps"] * ps.1, pats.data[a1.id, "ps"] * (1 - ps.1))
    }
    if (ps.est == F) {
      pats.data$ps <- ifelse(pats.data$l0 == 1, 0.7, 0.3)
      pats.data$ps <- ifelse(pats.data$A0 == 1, pats.data$ps, 1 - pats.data$ps)
      
      
      A1.beta <- c(-2.5, 0.8, 3, 1)
      ps.1 <- inv.logit(A1.beta[1] + A1.beta[2] * (pats.data$l0 == 1) + A1.beta[3] * (pats.data$A0 == 1) + A1.beta[4] * (pats.data$l1 == 1))
      
      a1.id <- which(pats.data$D1 == 0)
      pats.data[a1.id, "ps"] <- ifelse(pats.data[a1.id, "A1"] == 1, pats.data[a1.id, "ps"] * ps.1[a1.id], pats.data[a1.id, "ps"] * (1 - ps.1[a1.id]))
    }
  
  return(pats.data)
}



getallres.tv <- function(n.patients, ps.est) {
  for (i in 1:n.sims) {
    if (i %% 100 == 0) {
      print(i)
    }
    
    pats <- switch(
      toString(n.patients),
      "500"  = pats500.tv[[i]],
      "1500" = pats1500.tv[[i]],
      "5000" = pats5000.tv[[i]]
    )
    
    
    pats <- addw(pats, ps.est = ps.est)
    
    survivors <- pats[which(pats$D2 == 0), ]
    
    w.a0alive[i] <- get.q.tv(test.A = c(0, 0), survivors, tau = 0.5, type = "survivors")
    w.a1alive[i] <- get.q.tv(test.A = c(1, 1), survivors, tau = 0.5, type = "survivors")
    
    pats.a0surmed[i] <- median(pats[which(pats$A0 == 0 & pats$A1 == 0), ]$Y)
    pats.a1surmed[i] <- median(pats[which(pats$A0 == 1 & pats$A1 == 1), ]$Y)
    
    w.a0surmed[i] <- get.q.tv(test.A = c(0, 0), pats, tau = 0.5, type = "SIM")
    w.a1surmed[i] <- get.q.tv(test.A = c(1, 1), pats, tau = 0.5, type = "SIM")
  }
  res_df <- data.frame(w.a0alive,
                       w.a1alive,
                       pats.a0surmed,
                       pats.a1surmed,
                       w.a0surmed,
                       w.a1surmed)
  return(res_df)
}


##############parameters###############
n.sims <- 2000
w.a0alive <- numeric(n.sims)
w.a1alive <- numeric(n.sims)
pats.a0surmed <- numeric(n.sims)
pats.a1surmed <- numeric(n.sims)
w.a0surmed <- numeric(n.sims)
w.a1surmed <- numeric(n.sims)


#####################Estimated PS#####################
ps.est <- T
res.obt500est <- getallres.tv(500, ps.est)
res.obt1500est <- getallres.tv(1500, ps.est)
res.obt5000est <- getallres.tv(5000, ps.est)


truth <- c(2.457616, 1.228474, 1.725755, 0.7512144)


#rMSE results
round(sMSE(res.obt500est, truth), 3)
round(sMSE(res.obt1500est, truth), 3)
round(sMSE(res.obt5000est, truth), 3)

#bias results
round(sbias(res.obt500est, truth), 3)
round(sbias(res.obt1500est, truth), 3)
round(sbias(res.obt5000est, truth), 3)


w.a0surmed.sum <- cbind( c(sMSE(res.obt500est, truth)[5], sMSE(res.obt1500est, truth)[5], sMSE(res.obt5000est, truth)[5]),
                         c(sbias(res.obt500est, truth)[5], sbias(res.obt1500est, truth)[5], sbias(res.obt5000est, truth)[5]))

w.a1surmed.sum <- cbind( c(sMSE(res.obt500est, truth)[6], sMSE(res.obt1500est, truth)[6], sMSE(res.obt5000est, truth)[6]),
                         c(sbias(res.obt500est, truth)[6], sbias(res.obt1500est, truth)[6], sbias(res.obt5000est, truth)[6]))

o.a0surmed.sum <- cbind( c(sMSE(res.obt500est, truth)[3], sMSE(res.obt1500est, truth)[3], sMSE(res.obt5000est, truth)[3]),
                         c(sbias(res.obt500est, truth)[3], sbias(res.obt1500est, truth)[3], sbias(res.obt5000est, truth)[3]))

o.a1surmed.sum <- cbind(c(sMSE(res.obt500est, truth)[4], sMSE(res.obt1500est, truth)[4], sMSE(res.obt5000est, truth)[4]),
                        c(sbias(res.obt500est, truth)[4], sbias(res.obt1500est, truth)[4], sbias(res.obt5000est, truth)[4]))

summary_tab <- cbind(rbind(w.a0surmed.sum, w.a1surmed.sum), rbind(o.a0surmed.sum, o.a1surmed.sum))

rownames(summary_tab) <- c("a0_500", "a0_1500", "a0_5000", "a1_500", "a1_1500", "a1_5000")
colnames(summary_tab) <- c( "w.rmse", "w.bias", "o.rmse", "o.bias")

summary_tab

write.csv(summary_tab,  file ="TV.est.ps.res.csv")


#######################Known PS######################
ps.est <- F

res.obt500true <- getallres.tv(500, ps.est)
res.obt1500true <- getallres.tv(1500, ps.est)
res.obt5000true <- getallres.tv(5000, ps.est)

#rMSE results
round(sMSE(res.obt500true, truth), 3)
round(sMSE(res.obt1500true, truth), 3)
round(sMSE(res.obt5000true, truth), 3)

#bias results
round(sbias(res.obt500true, truth), 3)
round(sbias(res.obt1500true, truth), 3)
round(sbias(res.obt5000true, truth), 3)

w.a0surmed.sum <- cbind( c(sMSE(res.obt500true, truth)[5], sMSE(res.obt1500true, truth)[5], sMSE(res.obt5000true, truth)[5]),
                         c(sbias(res.obt500true, truth)[5], sbias(res.obt1500true, truth)[5], sbias(res.obt5000true, truth)[5]))

w.a1surmed.sum <- cbind( c(sMSE(res.obt500true, truth)[6], sMSE(res.obt1500true, truth)[6], sMSE(res.obt5000true, truth)[6]),
                         c(sbias(res.obt500true, truth)[6], sbias(res.obt1500true, truth)[6], sbias(res.obt5000true, truth)[6]))

o.a0surmed.sum <- cbind( c(sMSE(res.obt500true, truth)[3], sMSE(res.obt1500true, truth)[3], sMSE(res.obt5000true, truth)[3]),
                         c(sbias(res.obt500true, truth)[3], sbias(res.obt1500true, truth)[3], sbias(res.obt5000true, truth)[3]))

o.a1surmed.sum <- cbind(c(sMSE(res.obt500true, truth)[4], sMSE(res.obt1500true, truth)[4], sMSE(res.obt5000true, truth)[4]),
                        c(sbias(res.obt500true, truth)[4], sbias(res.obt1500true, truth)[4], sbias(res.obt5000true, truth)[4]))

summary_tab <- cbind(rbind(w.a0surmed.sum, w.a1surmed.sum), rbind(o.a0surmed.sum, o.a1surmed.sum))

rownames(summary_tab) <- c("a0_500", "a0_1500", "a0_5000", "a1_500", "a1_1500", "a1_5000")
colnames(summary_tab) <- c( "w.rmse", "w.bias", "o.rmse", "o.bias")

summary_tab

write.csv(summary_tab,  file = "TV.known.ps.res.csv")

